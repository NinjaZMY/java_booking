package booking_service.dq.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
